/**
 *
 * @author
 *
 */
var GameTest = (function (_super) {
    __extends(GameTest, _super);
    function GameTest() {
        _super.apply(this, arguments);
    }
    var d = __define,c=GameTest,p=c.prototype;
    return GameTest;
}(egret.DisplayObjectContainer));
egret.registerClass(GameTest,'GameTest');
//# sourceMappingURL=GameTest.js.map
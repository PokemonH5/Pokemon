/**
 *
 * @author 
 *
 */
class GameTest extends egret.DisplayObjectContainer {

    
    
    
        
}